const { chromium, devices } = require('playwright');
const fs = require('fs');
const B = 'http://localhost:8768';
const KEY = 'hifz-planner.v1';
const kid = (setup, extra) => Object.assign({ id: 'c1', name: 'Yasmine', setup: Object.assign({ surahs: [114], known: [], order: 'end', mode: 'amount', amount: 3, target: '', days: 'nnnnnoo', recent: 5, old: 10, time: '18:30', start: '2026-11-23' }, setup), learned: [], fragile: [], log: [], mp: 0 }, extra || {});
let ok = 0, ko = 0;
const check = (name, cond, info) => { cond ? ok++ : ko++; console.log((cond ? 'OK  ' : 'FAIL') + ' ' + name + (info ? '  — ' + info : '')); };
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ ...devices['iPhone 13'], permissions: ['clipboard-read', 'clipboard-write'] });
  const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  const at = async (date) => { await p.clock.setFixedTime(new Date(date + 'T10:00:00')); };
  const state = async (children) => { await p.goto(B + '/fr/'); await p.evaluate(([k, v]) => localStorage.setItem(k, JSON.stringify(v)), [KEY, { children, cur: children[0] && children[0].id }]); await p.reload(); await p.waitForSelector('.hz-today h2, .hz-form'); };
  const txt = async (sel) => (await p.innerText(sel)).replace(/\s+/g, ' ').trim();
  const newPassage = async () => (await p.$('.b-new .hz-passage')) ? txt('.b-new .hz-passage') : '';
  const stat = async (i) => (await p.$$eval('.hz-stats li b', l => l.map(x => x.innerText)))[i];

  // V0 — onboarding (mobile) : Al-Fatiha + 3 Qul
  await at('2026-11-23');
  await p.goto(B + '/fr/'); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForSelector('.hz-form');
  const t0 = Date.now();
  await p.check('input[name="pick"][value="qul"]');
  await p.fill('input[name="name"]', 'Yasmine');
  await p.click('[data-act="save-setup"]'); await p.waitForSelector('.hz-today h2');
  check('V0 parcours créé en 3 étapes', (await newPassage()).includes('Al-Fatihah, versets 1 à 3'), await newPassage());
  // V8 — retour : « Aujourd’hui » d’abord
  await p.reload(); await p.waitForSelector('.hz-today h2');
  check('V8 au retour, la page s’ouvre sur Aujourd’hui', await p.isHidden('.hz-setup') && await p.isVisible('.hz-today'), await txt('.hz-today h2'));

  // V1 — la coche suit les versets, pas la date
  await at('2026-11-23');
  await state([kid({ surahs: [114], amount: 1 })]);
  await p.click('[data-act="new-ok"]');
  await p.click('[data-act="edit"]'); await p.fill('input[name="amount"]', '3'); await p.click('[data-act="save-setup"]'); await p.waitForSelector('.hz-today h2');
  const v1Today = await txt('.hz-today');
  await at('2026-11-24'); await p.reload(); await p.waitForSelector('.hz-today h2');
  check('V1 verset 1 reste acquis après passage à 3 versets', (await stat(0)) === '1/6' && (await newPassage()) === 'An-Nas, versets 2 à 4', `stat ${await stat(0)} · demain : ${await newPassage()} · aujourd’hui : ${v1Today.slice(0, 80)}`);

  // V2 — dates écoulées ≠ réussite
  await at('2026-11-23');
  await state([kid({ surahs: [114], amount: 3, start: '2026-11-19' })]);
  const v2 = await txt('.hz-today');
  check('V2 séances manquées signalées, rien n’est « terminé »', /2 séances n’ont pas été faites/.test(v2) && (await newPassage()) === 'An-Nas, versets 1 à 3' && !(await p.$('.hz-miles-list li.is-done')), v2.slice(0, 120));

  // V3 — Reporter décale la fin d’une séance
  await state([kid({ surahs: [114, 113, 112], amount: 3 })]);
  const end1 = await stat(3);
  await p.click('[data-act="skip"]');
  const end2 = await stat(3);
  check('V3 « Reporter » décale la fin estimée', end1 !== end2, `${end1} → ${end2}`);

  // V4 — « À revoir » : le passage revient
  await state([kid({ surahs: [114, 113, 112], amount: 3 })]);
  await p.click('[data-act="new-again"]');
  await at('2026-11-24'); await p.reload(); await p.waitForSelector('.hz-today h2');
  check('V4 « À revoir » : même passage à la séance suivante', (await newPassage()) === 'An-Nas, versets 1 à 3', await newPassage());

  // V5 — date cible exacte
  await at('2026-11-23');
  await state([kid({ surahs: [114, 113, 112], mode: 'date', target: '2026-11-26', days: 'nnnnnnn' })]);
  const v5 = await txt('.hz-progress');
  check('V5 objectif du 26/11 tenu avec 5 versets/séance', /Rythme : 5 nouveaux versets par séance/.test(v5) && /tenu/.test(v5), v5.slice(-150));
  await state([kid({ surahs: [114, 113, 112], mode: 'date', target: '2026-11-23', days: 'nnnnnnn' })]);
  check('V5b objectif impossible signalé', /impossible/.test(await txt('.hz-progress')), (await txt('.hz-progress')).slice(-160));

  // V6 — révision seule + révision après la dernière leçon
  await state([kid({ surahs: [114, 113, 112], known: [114, 113, 112] })]);
  const v6 = await txt('.hz-today');
  check('V6 tout connu : séance de révision proposée', !(await p.$('.b-new')) && !!(await p.$('.b-old')) && /alhamdulillah/i.test(v6), v6.slice(0, 160));
  const learnedAlmost = []; // An-Nas sauf le dernier verset
  await state([kid({ surahs: [114], amount: 3 }, { learned: [6230, 6231, 6232], log: [{ d: '2026-11-20', ns: 'ok', n: [6230, 6232], view: { n: [6230, 6231, 6232], recent: [], old: [] } }] })]);
  await p.click('[data-act="new-ok"]');
  await at('2026-11-24'); await p.reload(); await p.waitForSelector('.hz-today h2');
  check('V6b après la dernière leçon, la révision continue', !(await p.$('.b-new')) && (!!(await p.$('.b-recent')) || !!(await p.$('.b-old'))), await txt('.hz-today'));

  // V7 — fiche de la semaine : texte + impression sur 1 page A4
  await at('2026-11-23');
  await state([kid({ surahs: range(114, 78), amount: 3 })]);
  const rows = await p.$$eval('.hz-week tbody tr', l => l.length);
  await p.click('[data-act="copy-week"]');
  const clip = await p.evaluate(() => navigator.clipboard.readText());
  check('V7 fiche : 7 jours + texte pour l’enseignant', rows === 7 && /Fiche de hifz de la semaine — Yasmine/.test(clip) && clip.split('\n').length >= 8, clip.split('\n').slice(0, 3).join(' / '));
  const pdf = await (await b.newContext()).newPage();
  await pdf.clock.setFixedTime(new Date('2026-11-23T10:00:00'));
  await pdf.goto(B + '/fr/'); await pdf.evaluate(([k, v]) => localStorage.setItem(k, JSON.stringify(v)), [KEY, { children: [kid({ surahs: range(114, 78), amount: 3 })], cur: 'c1' }]); await pdf.reload(); await pdf.waitForSelector('.hz-week tbody tr');
  const buf = await pdf.pdf({ format: 'A4' }); fs.writeFileSync('/home/user/ah3119/hifz/apercus/fiche-semaine.pdf', buf);
  const pages = (buf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
  check('V7b fiche imprimée sur une seule page A4', pages === 1, pages + ' page(s)');

  // V9 — plusieurs enfants
  await state([kid({ surahs: [114] }), Object.assign(kid({ surahs: [1] }), { id: 'c2', name: 'Adam' })]);
  await p.click('[data-act="new-ok"]');
  await p.click('[data-child="c2"]'); const adam = await newPassage();
  await p.click('[data-child="c1"]');
  check('V9 deux enfants, progressions séparées', adam === 'Al-Fatihah, versets 1 à 3' && (await stat(0)) === '3/6', `Adam : ${adam} · Yasmine : ${await stat(0)}`);

  // V11 — lien de sauvegarde sans prénom
  await p.click('[data-act="backup"]'); const link = await p.evaluate(() => navigator.clipboard.readText());
  const decoded = Buffer.from(link.split('#import=')[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString();
  const p2 = await (await b.newContext()).newPage(); await p2.clock.setFixedTime(new Date('2026-11-24T10:00:00'));
  await p2.goto(link); await p2.waitForSelector('.hz-import:not([hidden])'); await p2.click('[data-act="import-yes"]'); await p2.waitForSelector('.hz-today h2');
  const imp = await p2.$$eval('.hz-stats li b', l => l[0].innerText);
  check('V11 sauvegarde importée, sans prénom', imp === '3/6' && !/Yasmine/.test(decoded), `importé ${imp}`);

  // V12 — rappel agenda
  const [dl] = await Promise.all([p.waitForEvent('download'), p.click('[data-act="reminder"]')]);
  const ics = fs.readFileSync(await dl.path(), 'utf8');
  check('V12 rappel récurrent les jours de séance à 18:30', /RRULE:FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR/.test(ics) && /T183000/.test(ics), ics.match(/RRULE[^\r]*/)[0]);

  // V10 — mobile, traductions, erreurs
  for (const path of ['/fr/', '/']) {
    await p.goto(B + path); await p.waitForSelector('.hz-today h2');
    const ov = await p.evaluate(() => Math.max(document.documentElement.scrollWidth, innerWidth) - 390);
    const raw = await p.evaluate(() => (document.body.innerText.match(/\b[a-z]+_[a-z_]+\b/g) || []).filter(x => !/^sakina/.test(x)));
    check(`V10 ${path} sans débordement ni clé non traduite`, ov === 0 && raw.length === 0, `débordement ${ov}, clés ${raw.join(',')}`);
  }
  await p.goto(B + '/fr/'); await p.waitForSelector('.hz-today h2');
  await p.screenshot({ path: '/home/user/ah3119/hifz/apercus/pilote-aujourdhui.png' });
  await p.evaluate(() => document.querySelector('.hz-week').scrollIntoView()); await p.screenshot({ path: '/home/user/ah3119/hifz/apercus/pilote-fiche.png' });
  await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForSelector('.hz-form');
  await p.evaluate(() => document.querySelector('.hz-form').scrollIntoView()); await p.screenshot({ path: '/home/user/ah3119/hifz/apercus/pilote-creation.png' });
  check('Aucune erreur JavaScript', errs.length === 0, errs.join(' | '));
  console.log(`\n${ok} OK, ${ko} échec(s)`);
  await b.close();
  function range(a, z) { const o = []; for (let x = a; x >= z; x--) o.push(x); return o; }
})();
