const { chromium, devices } = require('playwright');
const B = 'http://localhost:8768';
const KEY = 'hifz-planner.v1';
const SHOT = '/tmp/claude-0/-home-user-ah3119/9ba3e272-c7b8-543a-8f84-96d3944a0eba/scratchpad/ml-shots/';
require('fs').mkdirSync(SHOT, { recursive: true });
const LANGS = ['en', 'zh', 'hi', 'es', 'ar', 'fr', 'bn', 'pt', 'ru', 'id'];
const home = (l) => (l === 'en' ? '/' : `/${l}/`);
let ok = 0, ko = 0;
const check = (name, cond, info) => { cond ? ok++ : ko++; console.log((cond ? 'OK  ' : 'FAIL') + ' ' + name + (info ? '  — ' + info : '')); };
const kid = { id: 'c1', name: '', setup: { surahs: [1, 112, 113, 114], known: [], order: 'end', mode: 'amount', amount: 3, target: '', days: 'nnnnnnn', recent: 5, old: 10, time: '18:30', start: '2026-11-23' }, learned: [], fragile: [], log: [], mp: 0 };

(async () => {
  const b = await chromium.launch();
  const errs = [];
  // 1) Chaque langue, sur petit écran (iPhone SE, 375 px) : rendu, sens d'écriture, clés, débordement, visionneuse
  const ctx = await b.newContext({ ...devices['iPhone SE'] });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(e.message));
  await p.clock.setFixedTime(new Date('2026-11-24T10:00:00'));
  for (const l of LANGS) {
    await p.goto(B + home(l));
    await p.evaluate(() => localStorage.clear());
    await p.reload(); await p.waitForSelector('.hz-form');
    const ov1 = await p.evaluate(() => document.documentElement.scrollWidth - innerWidth);
    await p.screenshot({ path: `${SHOT}${l}-setup.png`, fullPage: false });
    await p.evaluate(([k, v]) => localStorage.setItem(k, JSON.stringify(v)), [KEY, { children: [kid], cur: 'c1' }]);
    await p.reload(); await p.waitForSelector('.hz-today h2');
    const info = await p.evaluate(() => ({ lang: document.documentElement.lang, dir: document.documentElement.dir, title: document.title,
      raw: (document.body.innerText.match(/\b[a-z]+_[a-z_]+\b/g) || []), braces: /\{\{|\{[a-z]+\}/.test(document.body.innerText),
      passage: (document.querySelector('.b-new .hz-passage') || {}).innerText, btn: (document.querySelector('.hz-mushaf') || {}).innerText }));
    const ov2 = await p.evaluate(() => document.documentElement.scrollWidth - innerWidth);
    await p.screenshot({ path: `${SHOT}${l}-today.png`, fullPage: false });
    const wantDir = l === 'ar' ? 'rtl' : 'ltr';
    check(`${l} rendu`, info.dir === wantDir && !info.raw.length && !info.braces && ov1 <= 0 && ov2 <= 0,
      `lang=${info.lang} dir=${info.dir} débordement ${ov1}/${ov2} · « ${info.passage} » · ${info.btn}${info.raw.length ? ' · clés ' + info.raw : ''}`);
    // visionneuse du mushaf : page 1 (Al-Fatiha), puis page suivante, puis fermeture
    await p.click('.b-new .hz-mushaf');
    await p.waitForSelector('.hz-mushaf-view img');
    await p.waitForFunction(() => { const i = document.querySelector('.hz-mushaf-view img'); return i.complete && i.naturalWidth > 0; }, null, { timeout: 8000 });
    const v1 = await p.evaluate(() => ({ t: document.querySelector('.hz-mv-title').innerText, src: document.querySelector('.hz-mushaf-view img').getAttribute('src') }));
    if (l === 'ar' || l === 'zh') await p.screenshot({ path: `${SHOT}${l}-mushaf.png` });
    await p.click('.hz-mv-nav [data-go="1"]');
    await p.waitForFunction(() => { const i = document.querySelector('.hz-mushaf-view img'); return /002\.webp$/.test(i.src) && i.complete && i.naturalWidth > 0; }, null, { timeout: 8000 });
    await p.keyboard.press('Escape');
    const closed = await p.evaluate(() => !document.querySelector('.hz-mushaf-view'));
    check(`${l} mushaf`, /001\.webp$/.test(v1.src) && closed, `${v1.t} → page 2 → fermé`);
  }
  // Pages légales et informations dans chaque langue
  for (const l of LANGS) {
    for (const slug of ['about', 'privacy', 'legal']) {
      const r = await p.goto(B + home(l) + slug + '/');
      const t = await p.evaluate(() => document.body.innerText);
      if (r.status() !== 200 || /\{\{|TO COMPLETE|À COMPLÉTER/.test(t)) check(`${l}/${slug}`, false, `HTTP ${r.status()}`);
    }
  }
  check('30 pages À propos / Confidentialité / Mentions légales', true);

  // 2) Menu Langues : depuis l'anglais, choisir Français ; le plan de l'enfant suit
  await p.goto(B + '/'); await p.waitForSelector('.hz-today h2');
  await p.click('.lang-menu summary');
  await p.screenshot({ path: `${SHOT}menu.png` });
  await p.click('.lang-menu a[data-l="fr"]');
  await p.waitForURL(B + '/fr/'); await p.waitForSelector('.hz-today h2');
  const frTitle = await p.innerText('.hz-today h2');
  check('Menu Langues : English → Français, même plan', /Aujourd’hui/.test(frTitle) && (await p.innerText('.b-new .hz-passage')).includes('Al-Fatihah'), frTitle);
  const pref = await p.evaluate(() => localStorage.getItem('oqt.lang'));
  check('Choix de langue mémorisé', pref === 'fr', pref);

  // 3) Bandeau de suggestion selon la langue du téléphone
  for (const [loc, expect] of [['fr-FR', 'Ce site existe en français.'], ['bn-BD', 'এই ওয়েবসাইটটি বাংলায়ও পড়া যায়।'], ['en-US@bn', null], ['en-US', null], ['de-DE', null]]) {
    const c2 = await b.newContext({ locale: loc });
    const q = await c2.newPage();
    await q.goto(B + '/'); await q.waitForSelector('.hz-form');
    const banner = await q.evaluate(() => { const x = document.querySelector('.lang-suggest span'); return x ? x.textContent : null; });
    check(`Bandeau pour un téléphone ${loc}`, banner === expect, String(banner));
    if (expect) { await q.click('.lang-suggest button'); await q.reload(); await q.waitForSelector('.hz-form'); check(`  fermé, il ne revient pas (${loc})`, !(await q.$('.lang-suggest'))); }
    await c2.close();
  }
  // 4) Référencement : hreflang et x-default sur l'accueil anglais
  await p.goto(B + '/');
  const hl = await p.$$eval('link[rel="alternate"]', (x) => x.map((y) => y.hreflang));
  check('hreflang : 10 langues + x-default', hl.length === 11 && hl.includes('zh-Hans') && hl.includes('x-default'), hl.join(' '));
  check('Aucune erreur JavaScript', errs.length === 0, errs.join(' | '));
  console.log(`\n${ok} OK, ${ko} échec(s)`);
  await b.close();
})();
